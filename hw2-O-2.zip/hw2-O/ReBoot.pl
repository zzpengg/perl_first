#! /Perl64/bin/perl

use SNMP_util;
require "cgilib.pl";
&PrintHeader();
$MIB1 = "1.3.6.1.4.1.890.1.5.8.19.9.3.0";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
&snmpset("public\@$HOST", "$MIB1",'INTEGER',1);
print "<script type=\"text/javascript\">window.location.href = \"index.pl\"</script>";
