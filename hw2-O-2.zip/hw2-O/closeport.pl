#! /Perl64/bin/perl
require "cgilib.pl";
use SNMP_util;

&PrintHeader();

local ($buffer, @pairs, $pair, $name, $value, %FORM);
# Read in text
$ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;

if ($ENV{'REQUEST_METHOD'} eq "POST"){
   read(STDIN, $buffer, $ENV{'CONTENT_LENGTH'});
}else {
   $buffer = $ENV{'QUERY_STRING'};
}

# Split information into name/value pairs
@pairs = split(/&/, $buffer);

foreach $pair (@pairs) {
   ($name, $value) = split(/=/, $pair);
   $value =~ tr/+/ /;
   $value =~ s/%(..)/pack("C", hex($1))/eg;
   $FORM{$name} = $value;
}

$port =  $FORM{close};
#print $port;

$portstatus_OID = "1.3.6.1.2.1.2.2.1.7"; # IP
$HOST = "192.168.1.1";
#print $res;

(@portstatus) = &snmpwalk("public\@$HOST", "$portstatus_OID");
$k=0;
print @portstatus;
foreach $value (@portstatus){
  @sp = split(':',$value);
  $portstatus[$k] = $sp[1];
  #print $portstatus[$k];
  $k++;
}
#print $portstatus[$port-1];
if($portstatus[$port-1]==1)
{
  $portstatus[$port-1]=2;

}
elsif($portstatus[$port-1]==2)
{
  $portstatus[$port-1]=1;
}
# $port=$portnum+1;
# print $port;
#
$MIB1 = "1.3.6.1.2.1.2.2.1.7"; # IP
$HOST = "192.168.1.1";
$res = &snmpset("public\@$HOST", "$MIB1.$port", 'INTEGER', $portstatus[$port-1]);
#print $res;
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@IP_addr) = &snmpwalk("public\@$HOST", "$MIB1");
foreach $val (@IP_addr){
  #print $val;
  #print "\n";
}
print "<script type=\"text/javascript\">window.location.href = \"portStatus.pl\"</script>";
