#! /Perl64/bin/perl

print("Content-Type : text/html\n\n");
print("hello world");
