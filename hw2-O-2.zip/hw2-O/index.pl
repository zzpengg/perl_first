#! /Perl64/bin/perl
require "cgilib.pl";
use SNMP_util;
$MIB1 = "1.3.6.1.2.1.1.5.0 ";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($sysname) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "1.3.6.1.2.1.1.2.0 ";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($oid) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "1.3.6.1.2.1.1.3.0 ";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($sysuptime) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "1.3.6.1.2.1.1.7.0 ";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($sysservice) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "	1.3.6.1.4.1.890.1.5.8.19.1.7.0";#出廠年份
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($swyear) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "	1.3.6.1.4.1.890.1.5.8.19.1.6.0";#出廠月份
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($swmonth) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "	1.3.6.1.4.1.890.1.5.8.19.1.5.0";#出廠日期
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($swday) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "	1.3.6.1.4.1.890.1.5.8.19.1.10.0";#產品序號
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($snumber) = &snmpget("public\@$HOST", "$MIB1");
$MIB1 = "1.3.6.1.4.1.890.1.5.8.19.11.3.0";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
($maxnumofmngtip) = &snmpget("public\@$HOST", "$MIB1");
$HOST = "public\@192.168.1.1";
for($port = 1; $port <= 9; $port++)
{
  &snmpset("$HOST","1.3.6.1.4.1.890.1.5.8.19.2.2.1.1.$port",'INTEGER',1);
}
$message = << "HERE";
Content-Type:text/html\r\n\r\n
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Simple Sidebar - Start Bootstrap Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <script src="../w3data.js"></script>
</head>

<body>


        <!-- /#sidebar-wrapper -->
	<div id="wrapper">
		<div w3-include-html="../slidebar.html"></div>

<script>
w3IncludeHTML();
</script>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>$sysname</h1>
                        <table class="table table-striped">
                        <tr class="info"><td>Product Private OID</td><td>$oid</td></tr>
                        <tr class="success"><td>System Up Time</td><td>$sysuptime</td></tr>
                        <tr class="active"><td>System Service</td><td>$sysservice</td></tr>
                        <tr class="warning"><td>Date Of Manufacture</td><td>$swyear/$swmonth/$swday</td></tr>
                        <tr class="danger"><td>Product Serial Number</td><td>$snumber</td></tr>
                        <tr class="info"><td>Max Number Of Management IP</td><td>$maxnumofmngtip</td></tr>
                        </table>
                        <a href="ReBoot.pl"  class="btn btn-danger">Reboot</a>
                        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Slidebar</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- /#page-content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    \$("#menu-toggle").click(function(e) {
        e.preventDefault();
        \$("#wrapper").toggleClass("toggled");
    });
    </script>

</body>

</html>
HERE

print $message;
