#! /Perl64/bin/perl
require "cgilib.pl";
use SNMP_util;

&PrintHeader();




$MIB1 = ".1.3.6.1.2.1.2.2.1.5";
$HOST = "public\@192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
for($i=1;$i<=9;$i++){
($speed[$i]) = &snmpget("$HOST", "$MIB1.$i");
$speed[$i] = $speed[$i] / 1000000;
#print $value[$i];
}
# for($i=1;$i<=9;$i++)
# @values+=$value[$i];
# 分割線

$MIB1 = ".1.3.6.1.2.1.17.4.3.1.2";
$HOST = "public\@192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@valuemac) = &snmpwalk("$HOST","$MIB1");
#my $value = hex substr $value, 0, 1, '';
#$value = "0" . $value;
#use Encode qw(decode encode);
#$value = decode('utf8', $value,     Encode::FB_CROAK);
#$octets     = encode('UTF-8', $characters, Encode::FB_CROAK);


#my @months = map hex, qw/x240 x118 x28 x116 x212 x164 /;
#print "$_\n" for @months;
#print "test";
my @ansmac;
foreach $value (@valuemac){
  @sp = split(':', $value);
  $temp = $sp[1];

  @macs = split('\.', $sp[0]);
  $k=0;
  foreach my $va (@macs) {
    $macadd[$k] = sprintf("%x" , $va);
    #print "$macadd[$k]\n";
    $k++;
  }
  $macvalue = $macadd[0] . "\." . $macadd[1] . "\." . $macadd[2] . "\." . $macadd[3] . "\.". $macadd[4] . "\.". $macadd[5] ;
  $ansmac[$temp] = $macvalue;
#  print $sp[0];
#  print "<br>";
}


#my @valuemac = substr @valuemac, 23;



my @strr;

my @valuemacs = split(':', $valuemac);
$k=0;
foreach my $val (@valuemacs) {
  $strr[$k] = $val;
  #print "$val\n";
  $k++;
}

my $mac = $strr[0];
$port = $strr[1];
#print $mac;
#print $strr[1];


my @macadd;

my @macs = split('\.', $mac);

$k=0;
foreach my $va (@macs) {
  $macadd[$k] = sprintf("%x" , $va);
  #print "$macadd[$k]\n";
  $k++;
}

my $macvalue = $macadd[0] . "\." . $macadd[1] . "\." . $macadd[2] . "\." . $macadd[3] . "\.". $macadd[4] . "\.". $macadd[5] ;


$MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.2"; # IP
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@IP_addr) = &snmpwalk("public\@$HOST", "$MIB1");
my @IPaddr;
$k=0;
foreach $val (@IP_addr)
{
  #print $val;
  @sp = split(':', $val);
  $IPaddr[$k] = $sp[1];
  #print $sp[1];
#  print "\n";
  $k++;
}


#print $macvalue;


$MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.3";
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@value) = &snmpwalk("public\@$HOST", "$MIB1");
my @macAddrr;
my @ansip;
$k=0;

foreach $val (@value)
{
  @temp = split(':', $val);
  $macAddrr[$k] = $temp[1];
  $temp[0] =  substr $temp[0], 0, -2;
  #print $temp[0];
  @ASCII = unpack("C*", $macAddrr[$k]);
  #print "\nASCII : \n";
  $mac =  join(".", map { unpack "H*", chr } @ASCII), $/;
  for($i=1;$i<=9;$i++){
    #print $i.":";
    #print $ansmac[$i];
    if($mac eq $ansmac[$i]){
      $ansip[$i] = $temp[0];
    }
  }
  #print $k;
  $k++;
}

$portstatus_OID = "1.3.6.1.2.1.2.2.1.7"; # IP
$HOST = "192.168.1.1";
#print $res;
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@portstatus) = &snmpwalk("public\@$HOST", "$portstatus_OID");
$k=0;
foreach $value (@portstatus){
  @sp = split(':',$value);
  $portstatus[$k] = $sp[1];
#  print $portstatus[$k];
  $k++;
}



$html = << "HERE";
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Mac</title>
    <!-- Bootstrap Core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/simple-sidebar.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css" integrity="sha384-AysaV+vQoT3kOAXZkl02PThvDr8HYKPZhNT5h/CXfBThSRXQ6jW5DO2ekP5ViFdi" crossorigin="anonymous">
  </head>
  <!--<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" integrity="sha384-3ceskX3iaEnIogmQchP8opvBy3Mi7Ce34nWjpBIwVTHfGYWQS9jwHDVRnpKKHJg7" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.3.7/js/tether.min.js" integrity="sha384-XTs3FgkjiBgo8qjEjBk0tGmf3wPrWtA6coPfQDfFEY8AnYJwjalXCiosYRBIBZX8" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/js/bootstrap.min.js" integrity="sha384-BLiI7JTZm+JWlgKa0M0kGRpJbF2J8q+qreVrKBC47e3K6BW78kGLrCkeRX6I9RoK" crossorigin="anonymous"></script>
  <script src="http://www.w3schools.com/lib/w3data.js"></script>
  <script>
      if("$portstatus[2]" == "1")
        document.getElementById("port3").innerHTML = "關掉";
      }else if("$portstatus[2]" == "2"){
        document.getElementById("port3").innerHTML = "打開";
      }
  </script>
  <body >

  <!-- /#sidebar-wrapper -->
<div id="wrapper">
<div w3-include-html="../slidebar.html"></div>

<script>
w3IncludeHTML();
</script>
  <!-- Page Content -->
  <div id="page-content-wrapper">
      <div class="container-fluid">
          <div class="row">
              <div class="col-lg-12">
              <div class="table-responsive">
                <table class="table">
                    <tr><td>port</td><td>speed</td><td>Mac address</td><td>IP address</td></tr>
                      <form action="closeport.pl" method="POST"><tr><td>1</td><td>$speed[1]</td><td>$ansmac[1]</td><td>$ansip[1]</td><td><button id = "port1" class="btn btn-danger" type="submit" value="1" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>2</td><td>$speed[2]</td><td>$ansmac[2]</td><td>$ansip[2]</td><td><button id = "port2" class="btn btn-danger" type="submit" value="2" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>3</td><td>$speed[3]</td><td>$ansmac[3]</td><td>$ansip[3]</td><td><button id = "port3" class="btn btn-danger" type="submit" value="3" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>4</td><td>$speed[4]</td><td>$ansmac[4]</td><td>$ansip[4]</td><td><button id = "port4" class="btn btn-danger" type="submit" value="4" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>5</td><td>$speed[5]</td><td>$ansmac[5]</td><td>$ansip[5]</td><td><button id = "port5" class="btn btn-danger" type="submit" value="5" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>6</td><td>$speed[6]</td><td>$ansmac[6]</td><td>$ansip[6]</td><td><button id = "port6" class="btn btn-danger" type="submit" value="6" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>7</td><td>$speed[7]</td><td>$ansmac[7]</td><td>$ansip[7]</td><td><button id = "port7" class="btn btn-danger" type="submit" value="7" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>8</td><td>$speed[8]</td><td>$ansmac[8]</td><td>$ansip[8]</td><td><button id = "port8" class="btn btn-danger" type="submit" value="8" name="close">關掉</td></tr></form>
                      <form action="closeport.pl" method="POST"><tr><td>9</td><td>$speed[9]</td><td>$ansmac[9]</td><td>$ansip[9]</td><td><button id = "port9" class="btn btn-danger" type="submit" value="9" name="close">關掉</td></tr></form>
                   </table>
                   <script>
                   str1="$portstatus[8]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port9").innerHTML = "關掉";
                         document.getElementById('port9').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port9").innerHTML = "打開";
                         document.getElementById('port9').className="btn btn-success";
                       }
                   </script>

                   <script>
                   str1="$portstatus[0]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port1").innerHTML = "關掉";
                         document.getElementById('port1').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port1").innerHTML = "打開";
                         document.getElementById('port1').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[1]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port2").innerHTML = "關掉";
                         document.getElementById('port2').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port2").innerHTML = "打開";
                         document.getElementById('port2').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[2]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port3").innerHTML = "關掉";
                         document.getElementById('port3').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port3").innerHTML = "打開";
                         document.getElementById('port3').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[3]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port4").innerHTML = "關掉";
                         document.getElementById('port4').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port4").innerHTML = "打開";
                         document.getElementById('port4').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[4]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port5").innerHTML = "關掉";
                         document.getElementById('port5').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port5").innerHTML = "打開";
                         document.getElementById('port5').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[5]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port6").innerHTML = "關掉";
                         document.getElementById('port6').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port6").innerHTML = "打開";
                         document.getElementById('port6').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[6]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port7").innerHTML = "關掉";
                         document.getElementById('port7').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port7").innerHTML = "打開";
                         document.getElementById('port7').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[7]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port8").innerHTML = "關掉";
                         document.getElementById('port8').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port8").innerHTML = "打開";
                         document.getElementById('port8').className="btn btn-success";
                       }
                   </script>
                   <script>
                   str1="$portstatus[8]";
                   var n=str1.localeCompare("1");
                   var p=str1.localeCompare("2");
                       if(n==0){
                         document.getElementById("port9").innerHTML = "關掉";
                         document.getElementById('port9').className="btn btn-danger";
                       }else if(p==0){
                         document.getElementById("port9").innerHTML = "打開";
                         document.getElementById('port9').className="btn btn-success";
                       }
                   </script>
                  </div>
              </div>
          </div>
      </div>
  </div>
  <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Slidebar</a>
  <!-- /#page-content-wrapper -->

</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    \$("#menu-toggle").click(function(e) {
        e.preventDefault();
        \$("#wrapper").toggleClass("toggled");
    });
    </script>
  </body>
</html>
HERE
print $html;
