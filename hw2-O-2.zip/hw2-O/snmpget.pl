#! /Perl64/bin/perl
use SNMP_util;

# print "Content-Type:text/html\r\n\r\n";
# print"<html><body>gg</body></html>";

$MIB1 = "1.3.6.1.2.1.2.2.1.7"; # IP
$HOST = "192.168.1.1";
$res = &snmpset("public\@$HOST", "1.3.6.1.2.1.2.2.1.7.5", 'INTEGER', 1);
print $res;
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@IP_addr) = &snmpwalk("public\@$HOST", "$MIB1");
foreach $val (@IP_addr){
  print $val;
  print "\n";
}




# $MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.2"; # IP
# $HOST = "192.168.1.1";
# ($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
# (@IP_addr) = &snmpwalk("public\@$HOST", "$MIB1");
# my @IPaddr;
# $k=0;
# foreach $val (@IP_addr)
# {
#   #print $val;
#   @sp = split(':', $val);
#   print $sp[0];
#   print "\n";
#   $IPaddr[$k] = $sp[1];
#   print $sp[1];
# #  print "\n";
#   $k++;
# }

# $MIB1 = "1.3.6.1.2.1.17.4.3.1.2";
# $HOST = "192.168.1.1";
# ($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
# (@value) = &snmpwalk("public\@$HOST", "$MIB1");
# my @macAddrr;
# $k=0;
# foreach $value (@value){
#   print $value;
#   print "\n";
# }

#
# $MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.3";
# $HOST = "192.168.1.1";
# ($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
# (@value) = &snmpwalk("public\@$HOST", "$MIB1");
# my @macAddrr;
# $k=0;
# foreach $val (@value)
# {
#   @temp = split(':', $val);
#   $macAddrr[$k] = $temp[1];
#   #print $temp[1];
#   #print "\n";
#   $k++;
# }
#
# foreach $val (@macAddrr)
# {
#   print $val;
#   @ASCII = unpack("C*", $val);
#   print "\nASCII : \n";
#   $mac =  join(", ", map { unpack "H*", chr } @ASCII), $/;
#   print $mac;
#   print "\n";
# }

# $MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.3";
# $HOST = "192.168.1.1";
# ($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
# (@value) = &snmpwalk("public\@$HOST", "$MIB1");
# foreach $val (@value)
# {
#   @temp = split(':', $val);
#   $macAddrr[$k] = $temp[1];
#   #print $temp[1];
#   #print "\n";
#   $k++;
# }

# my @hex = split /:/, $value;
# my @hex = unpack ("h*", $fields);
# if ($value) { print "Results :$MIB1:";
# foreach my $text (@hex)
# {
#     $var=unpack("h*",$text);
#     printf ("%x", hex ($var));
# }
# }
#else { warn "No response from host :$HOST:\n"; }
