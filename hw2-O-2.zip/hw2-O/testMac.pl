#! /Perl64/bin/perl

require "cgilib.pl";
use SNMP_util;


$MIB1 = "1.3.6.1.4.1.890.1.5.8.19.18.1.1.3"; # IP
$HOST = "192.168.1.1";
($MIB1) && ($HOST) || die "Usage: $0 MIB_OID HOSTNAME";
(@test1) = &snmpwalk("public\@$HOST", "$MIB1");
$k=0;
foreach $val (@test1){
  print $val;
  print "\n";
}



for($a = 0;$a <= $#test1; $a++)
{
 #$test1[$a] = sprintf("%02X",$test1[$a]);
  print "$test1[$a]:\n";

  my @total = split(/\./, $test1[$a]);
  my @total1 = split(/\:/,$total[$#total]);
  print "port$total1[$#total1]: ";
  for($i = 0;$i <=$#total;$i++)
  {
     #print "$total[$i]";
	 #my @total1 = split(/\:/, $total[$i]);
     $total[$i] = sprintf("%02X",$total[$i]);
	 print "$total[$i]:";
  }
    print "\n";
}
