#! /Perl64/bin/perl
require "cgilib.pl";
use SNMP_util;

&PrintHeader();

$MIB = ".1.3.6.1.4.1.890.1.5.8.19.8";
$HOST = "public\@192.168.1.1";
for($i=4;$i<=9;$i++){
  ($value[$i]) = &snmpget("$HOST", "$MIB.$i.0");
}

$html = << "HERE";
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>TimeManager</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css" integrity="sha384-AysaV+vQoT3kOAXZkl02PThvDr8HYKPZhNT5h/CXfBThSRXQ6jW5DO2ekP5ViFdi" crossorigin="anonymous">
  <!-- Bootstrap Core CSS -->
  <link href="../css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <link href="../css/simple-sidebar.css" rel="stylesheet">
  </head>
  <!--<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" integrity="sha384-3ceskX3iaEnIogmQchP8opvBy3Mi7Ce34nWjpBIwVTHfGYWQS9jwHDVRnpKKHJg7" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.3.7/js/tether.min.js" integrity="sha384-XTs3FgkjiBgo8qjEjBk0tGmf3wPrWtA6coPfQDfFEY8AnYJwjalXCiosYRBIBZX8" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/js/bootstrap.min.js" integrity="sha384-BLiI7JTZm+JWlgKa0M0kGRpJbF2J8q+qreVrKBC47e3K6BW78kGLrCkeRX6I9RoK" crossorigin="anonymous"></script>
  <script src="../w3data.js"></script>
  <!--<script>
    \$(function() {
      \$( "#datepicker" ).datepicker();
    });
  </script>-->
  <body>
  <div id="wrapper">
    <div w3-include-html="../slidebar.html"></div>

<script>
w3IncludeHTML();
</script>
        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                    <div class="row" style= "text-align:center;font-size:20px;">
                      <span>Switch現在時間 : </span>
                      <span>$value[4]年</span>
                      <span>$value[5]月</span>
                      <span>$value[6]日</span>
                      <span>$value[7]點</span>
                      <span>$value[8]分</span>
                      <span>$value[9]秒</span>
                    </div>
                    <br>
                    <form action="setTime.pl" method="POST" class="form-inline">
                      <div class="form-group" style="width:150px;">
                          <select class="form-control" name="year"style="height:50px;">
                            <script>
                            for (count=1970;count<2051;count+=1)
                            document.write("<option>"+count+"</option>");
                            </script>
                          </select>
                        <label for="year">年</label>
                      </div>
                      <div class="form-group" style="width:150px;">

                          <select class="form-control" name="month"style="height:50px;">
                            <script>
                              for (count=1;count<=12;count+=1)
                              document.write("<option>"+count+"</option>");
                            </script>
                          </select>
                          <label for="month">月</label>
                      </div>
                      <div class="form-group" style="width:150px;">

                          <select class="form-control" name="day"style="height:50px;">
                          <script>
                            for (count=1;count<=31;count+=1)
                            document.write("<option>"+count+"</option>");
                            </script>
                          </select>
                          <label for="month">日</label>
                      </div>
                      <div class="form-group" style="width:150px;">

                          <select class="form-control" name="hour"style="height:50px;">
                          <script>
                            for (count=0;count<24;count+=1)
                            document.write("<option>"+count+"</option>");
                            </script>
                          </select>
                        <label for="month">時</label>
                      </div>
                      <div class="form-group" style="width:150px;">

                          <select class="form-control" name="minute" style="height:50px;">
                          <script>
                            for (count=0;count<=59;count+=1)
                            document.write("<option>"+count+"</option>");
                            </script>
                          </select>
                          <label for="month">分</label>
                      </div>
                      <input type="submit" value="Submit" class="btn btn-primary">
                    </form>
                    </div>
                </div>
            </div>
        </div>
         <a href="#menu-toggle" class="btn btn-default" id="menu-toggle">Slidebar</a>
        <!-- /#page-content-wrapper -->

    </div>

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../js/bootstrap.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    \$("#menu-toggle").click(function(e) {
        e.preventDefault();
        \$("#wrapper").toggleClass("toggled");
    });
    </script>

  </body>
</html>
HERE
print $html;
